<?php

global $states;

$states['SV'] = array(
    "SV-AH" => "Ahuachapán",
    "SV-CA" => "Cabañas",
    "SV-CH" => "Chalatenango",
    "SV-CU" => "Cuscatlán",
    "SV-LI" => "La Libertad",
    "SV-PA" => "La Paz",
    "SV-UN" => "La Unión",
    "SV-MO" => "Morazán",
    "SV-SM" => "San Miguel",
    "SV-SS" => "San Salvador",
    "SV-SV" => "San Vicente",
    "SV-SA" => "Santa Ana",
    "SV-SO" => "Sonsonate",
    "SV-US" => "Usulután",
);
